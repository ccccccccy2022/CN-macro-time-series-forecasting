
import sys
import pandas as pd
import numpy as np
class filter1:
    def __init__(self,filter_name,strainx,train_y,test_x,k,n_for,nnn=1,t=0):
        '''
        :param filter_name: 特征工程名字，'CORT'，'Pearson'，'HMImage_1_a'/'HMImage_1_p'/'HMImage_1_d'/'HMImage_2_a'/
        'HMImage_2_p'/'HMImage_2_d'/'HMImage_3_a'/ 'HMImage_3_p'/ 'HMImage_3_d'/ 'Image_4_a'/ 'HMImage_4_p'/ 'HMImage_4_d'，'DTWfilter'，'Causalfilter'（ANM)
        :param strainx:特征x，[dataframe]
        :param train_y:特征y,[numpy.array]
        :param test_x:特征x验证集部分，[dataframe]
        :param k:阈值或者特征个数，CORT和Pearson给的是阈值，其余方法控制的是特征的个数
        :param t:再最新的DTWfilter和Causalfilter里可以作为特征得分的截取点,默认t=0，那就是取排名靠前的前k个特征，如果t=n,那么截取的是（n,n+k)的特征
        :param nnn:适配大程序的多期滚动，集群将多期循环工作已做拆解，默认为1期滚动
        :param n_for:预测长度
        '''
        self.filter_name=filter_name
        self.strainx=strainx
        self.train_y=train_y
        self.test_x=test_x
        self.k=k
        self.t=int(t)
        self.nnn=nnn
        self.n_for=n_for
        self.train_x2 = list(np.zeros((self.nnn, 1)))
        self.test_x2 = list(np.zeros((self.nnn, 1)))

    def cort_func(self,d2,d1_d1):
        d22 = d2[:-1]
        d2_ = d2[1:]
        d2_d2 = d2_ - d22
        cort = np.abs(np.dot(d2_d2.T, d1_d1) / (np.sqrt(np.dot(d2_d2.T, d2_d2)) * np.sqrt(np.dot(d1_d1.T, d1_d1))))
        return cort
    def CORT(self):
        for j in range(self.nnn):
            d1 = pd.DataFrame(self.train_y[j]).iloc[:-1,:]
            d1_=pd.DataFrame(pd.DataFrame(self.train_y[j]).iloc[1:,:].values,index=range(self.train_y[j].shape[0]-1))
            d1_d1=d1_-d1
            index = []
            ii = 0
            while np.array(index).shape[0] == 0 and self.k - ii*0.1 > 0:
                print(str(self.k-ii*0.1))
                cort=np.apply_along_axis(self.cort_func,0,np.array(self.strainx[j]))
                cortm=pd.DataFrame(cort.reshape(1,len(cort.flatten())),columns=pd.DataFrame(self.strainx[j]).columns)
                cortaddname=cortm[cortm>(self.k - ii * 0.1)].dropna(axis=1).columns
                index=index+list(cortaddname)
                ii = ii + 1

        return index
    def Pearson(self):
        for j in range(self.nnn):
            k2 = 0.8
            X_num = 80

            def findcorr(Ytrain_roll, Xtrain_roll, k1_1, X_num):
                while 1:
                    chooseXmatrix2 = column_matrix_corr_matrix(Ytrain_roll, Xtrain_roll, k1_1)
                    k1_1 -= 0.05
                    if chooseXmatrix2.shape[1] > X_num:
                        break
                return chooseXmatrix2.columns, k1_1

            chooseX1, k1_1 = findcorr(self.train_y[j], self.strainx[j], self.k, X_num)
            tmptestx = pd.DataFrame(self.test_x[j],columns=self.strainx[j].columns)
            chooseX2, k1_2 = findcorr(self.train_y[j][-self.n_for: ],tmptestx, self.k, X_num)
            XnameAll0 = chooseX1 & chooseX2

            while len(chooseX1) < 100:
                X_num += 100
                chooseX1, k1_1 = findcorr(self.train_y[j],self.strainx[j], k1_1, X_num)
                chooseX2, k1_2 = findcorr(self.train_y[j].iloc[-self.n_for:, ], self.test_x[j], k1_2, X_num)
                XnameAll0 = chooseX1 & chooseX2

            if len(XnameAll0)>1:
                chooseXmatrix3 = del_dupli(self.strainx[j][XnameAll0], k2)
        return chooseXmatrix3.columns
    def HMImage(self):
        if 'step' in filter_name:
            print('image_step')
            pic_len = int(64 / 72 * self.strainx[0].shape[0])
            if pic_len % 2 != 0:
                pic_len += 1
            image_method = int(filter_name[8])
            Hash_method = filter_name[10]
            feature_step = 1
            try:
                feature_step = int(filter_name[-1])
            except:
                pass
            print('feature_step={}'.format(feature_step))
            feature_index = list(set(
                np.linspace(0, np.floor(self.nnn / feature_step) * feature_step, int(np.floor(self.nnn / feature_step)),
                            endpoint=False, dtype=int)))
            if len(feature_index) == 0:
                feature_index = [0]
            print('要计算的期数为{}'.format(feature_index))
            feature_index.sort()
            strainx_cal = []
            train_y_cal = []
            test_x_cal = []
            for ff in feature_index:
                strainx_cal.append(self.strainx[ff])
                train_y_cal.append(self.train_y[ff])
                test_x_cal.append(self.test_x[ff])
            nnn_cal = len(feature_index)
            train_x2_cal = list(map(lambda x: cal_HMD(strainx_cal[x], train_y_cal[x], test_x_cal[x], list([pic_len]),
                                                      list([image_method]), list([int(self.k)]), list([Hash_method]))[0],
                                    range(nnn_cal)))
            test_x2_cal = list(map(lambda x: cal_HMD(strainx_cal[x], train_y_cal[x], test_x_cal[x], list([pic_len]),
                                                     list([image_method]), list([int(self.k)]), list([Hash_method]))[1],
                                   range(nnn_cal)))
            train_x2 = []
            test_x2 = []
            for j in range(self.nnn):
                if j in feature_index:
                    train_x2.append(train_x2_cal[feature_index.index(j)])
                    test_x2.append(test_x2_cal[feature_index.index(j)])
                    print("第{}个滚动期，计算特征工程".format(j + 1))
                else:
                    train_x2.append(self.strainx[j][train_x2[-1].columns])
                    tmptestx2 = pd.DataFrame(self.test_x[j], columns=self.strainx[j].columns)
                    test_x2.append(tmptestx2[test_x2[-1].columns])
                    print("第{}个滚动期，不计算特征工程".format(j + 1))
        else:
            print('image')
            pic_len = int(64 / 72 * self.strainx[0].shape[0])
            if pic_len % 2 != 0:
                pic_len += 1
            image_method = int(filter_name[8])
            Hash_method = filter_name[-1]
            from multiprocessing import Pool
            from model_tools.Multi import cal_HMD
            # zip_args = list(zip(strainx, train_y, test_x, [list([pic_len]) for x in range(nnn)],
            #                     [list([image_method]) for x in range(nnn)], [list([k]) for x in range(nnn)],
            #                     [list([Hash_method]) for x in range(nnn)]))
            # pool = Pool(processes=6)
            # res = pool.starmap(cal_HMD, zip_args)
            # pool.close()
            # pool.join()
            train_x2 = list(map(lambda x:
                                cal_HMD(self.strainx[x], self.train_y[x], self.test_x[x], list([pic_len]), list([image_method]),
                                        list([self.k]), list([Hash_method]))[0], range(self.nnn),list([self.t])))
            print(train_x2)
            test_x2 = list(map(lambda x:
                               cal_HMD(self.strainx[x], self.train_y[x], self.test_x[x], list([pic_len]), list([image_method]),
                                       list([self.k]), list([Hash_method]))[1], range(self.nnn),list([self.t])))
        return train_x2,test_x2
    def DWTfilter(self):
        from model_tools.Multi import DTW_filter
        from multiprocessing import Pool
        zip_args = list(zip(self.strainx, self.train_y, self.test_x,  [int(self.k) for x in range(self.nnn)],[int(self.t) for x in range(self.nnn)]))
        with Pool() as pool:
            pool = Pool(processes=6)
            res = pool.starmap(DTW_filter, zip_args)
            pool.close()
            pool.join()
        train_x2 = list(map(lambda x: res[x][0], range(self.nnn)))
        print(train_x2)
        test_x2 = list(map(lambda x: res[x][1], range(self.nnn)))
        return train_x2,test_x2
    def Causalfilter(self):
        from cdt.independence.graph import RFECVLinearSVR
        from cdt.causality.pairwise import ANM
        import math
        G=RFECVLinearSVR()
        G2 = ANM()
        def func(cutx,train_y):
            skeleton = G.predict(pd.concat([pd.DataFrame(train_y, columns=['y']), cutx], axis=1))
            output_graph = G2.predict(pd.concat([pd.DataFrame(train_y, columns=['y']), cutx], axis=1), skeleton)
            print('*')
            ans1 = pd.DataFrame(list(output_graph.edges(data='weight')), columns=['Cause', 'Effect', 'Score'])
            ans2 = ans1.sort_values(by='Score', ascending=False)
            score =ans2[ans2['Effect'] == 'y'].iloc[0, :]
            nameindex=ans2[ans2['Effect'] == 'y']['Cause'].iloc[0]
            return score,nameindex
        CUTXlist=[]
        for j in range(self.nnn):
            part = math.ceil(self.strainx[j].shape[1] / int(self.k))
            i = 0
            while part > self.strainx[j].shape[0] * 1 / 4:
                i = i + 1
                part = math.ceil(self.strainx[j].shape[1] / (i * int(self.k)))
        for cut in range((i+1) * int(self.k)):
            try:
                CUTXlist.append(self.strainx[j].iloc[:, part * cut:part * (cut + 1)])
            except:
                CUTXlist.append(self.strainx[j].iloc[:, part * cut:])


        for j in range(self.nnn):
            part=math.ceil(self.strainx[j].shape[1]/int(self.k))
            i=0
            while part>self.strainx[j].shape[0]*1/4:
                i=i+1
                part =math.ceil(self.strainx[j].shape[1]/(i*int(self.k)))

            score=pd.DataFrame()
            nameindex=[]
            for cutx in CUTXlist:
                score1, nameindex1 = func(cutx, self.train_y[j])
                try:
                    score=pd.concat([score,score1],axis=1)
                    nameindex.append(nameindex1)
                except:pass
            score.columns = score.loc['Cause']
        return list(score.loc['Score'].sort_values(ascending=False).index[int(self.t):int(self.t)+int(self.k)])

    def forward(self):
        if self.filter_name=='CORT':
            index=self.CORT()
            for j in range(self.nnn):
                if np.array(index).shape[0]==0:
                    print("阈值提取特征失败")
                    self.train_x2[j] = self.strainx[j]
                    self.test_x2[j] = self.test_x[j]
                else:
                    self.train_x2[j]=pd.DataFrame(pd.DataFrame(self.strainx[j])[index])
                    if self.test_x[j].shape[0] != 0:
                       self.test_x2[j]=pd.DataFrame(pd.DataFrame(self.test_x[j],columns=self.strainx[j].columns)[index])
            return self.train_x2,self.test_x2
        if self.filter_name=='Pearson':
            index=self.Pearson()
            for j in range(self.nnn):
                if np.array(index).shape[0]==0:
                    print("阈值提取特征失败")
                    self.train_x2[j] = self.strainx[j]
                    self.test_x2[j] = self.test_x[j]
                else:
                    self.train_x2[j]=pd.DataFrame(pd.DataFrame(self.strainx[j])[index])
                    if self.test_x[j].shape[0] != 0:
                       self.test_x2[j]=pd.DataFrame(pd.DataFrame(self.test_x[j],columns=self.strainx[j].columns)[index])
        if self.filter_name[0:7] == "HMImage":
            return self.HMImage()
        if self.filter_name =='DTWfilter':
            return self.DWTfilter()
        if self.filter_name =='Causalfilter':
            index = self.Causalfilter()
            for j in range(self.nnn):
                if np.array(index).shape[0] == 0:
                    print("阈值提取特征失败")
                    self.train_x2[j] = self.strainx[j]
                    self.test_x2[j] = self.test_x[j]
                else:
                    self.train_x2[j] = pd.DataFrame(pd.DataFrame(self.strainx[j])[index])
                    if self.test_x[j].shape[0] != 0:
                        self.test_x2[j] = pd.DataFrame(
                            pd.DataFrame(self.test_x[j], columns=self.strainx[j].columns)[index])
            return self.train_x2, self.test_x2

if __name__ =='__main__':
    import pickle
    filter_name='DTW_filter'
