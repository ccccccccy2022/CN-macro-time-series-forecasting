# !/usr/bin/env python3
# -*- coding:utf-8 -*-

# @Time    : 2022/06/16 30:27
# @Author  : TJD
# @FileName: feature_engine2.py
import sys
import time

import pandas as pd
import numpy as np
import math
from platform import platform

from model_tools.Multi import column_matrix_corr_matrix, del_dupli


class Filter:
    def __init__(self, strainx, train_y, test_x, k, n_for, nnn=1, t=0,framelist=None):
        '''
        :param filter_name: 特征工程名字，'CORT'，'Pearson'，'HMImage_1_a'/'HMImage_1_p'/'HMImage_1_d'/'HMImage_2_a'/
        'HMImage_2_p'/'HMImage_2_d'/'HMImage_3_a'/ 'HMImage_3_p'/ 'HMImage_3_d'/ 'Image_4_a'/ 'HMImage_4_p'/ 'HMImage_4_d'，'DTWfilter'，'Causalfilter'（ANM)
        :param strainx:特征x，[dataframe]
        :param train_y:特征y,[numpy.array]
        :param test_x:特征x验证集部分，[dataframe]
        :param k:阈值或者特征个数，CORT和Pearson给的是阈值，其余方法控制的是特征的个数
        :param t:再最新的DTWfilter和Causalfilter里可以作为特征得分的截取点,默认t=0，那就是取排名靠前的前k个特征，如果t=n,那么截取的是（n,n+k)的特征
        :param nnn:适配大程序的多期滚动，集群将多期循环工作已做拆解，默认为1期滚动
        :param n_for:预测长度
        :framelist:框架特征的名称list
        '''
        self.strainx = strainx
        self.train_y = train_y
        self.test_x = test_x
        self.k = k
        self.t = int(t)
        self.nnn = nnn
        self.n_for = n_for
        self.train_x2 = list(np.zeros((self.nnn, 1)))
        self.test_x2 = list(np.zeros((self.nnn, 1)))
        self.framelist=framelist

    def __getdata(self, ynum):
        columns = self.strainx[0].columns.to_list()
        row, col = self.strainx[0].shape[0], self.strainx[0].shape[1]
        ylen = int(row / ynum)
        nfor = int(self.test_x[0].shape[0] / ynum)
        train_x_data, train_y_data, test_x_data = [], [], []
        for i in range(ynum):
            train_x_data.append(self.strainx[0].iloc[i * ylen:(i + 1) * ylen, :])
            train_y_data.append(pd.DataFrame(self.train_y[0][i * ylen:(i + 1) * ylen]))
            test_x_data.append(self.test_x[0].iloc[i * nfor:(i + 1) * nfor, :])
        return train_x_data, train_y_data, test_x_data

    def ray_source_management(self):
        """
        针对并行计算需要启动ray而进行资源管理
        :return:
        """
        pass

    def causal_filter(self, ynum, method='anm', k1=10,Train_y=None):
        """
        实例化CausalFilter，并默认使用anm方法
        :return:
        """
        train_x, train_y, test_x = self.__getdata(ynum)
        if Train_y is None:
            k = self.k
            filter = CausalFilter(train_x=train_x,
                                  train_y=train_y,
                                  test_x=test_x,
                                  nnn=self.nnn)
        else:
            filter = CausalFilter(train_x=train_x,
                                  train_y=Train_y,
                                  test_x=test_x,
                                  nnn=self.nnn)
            k =k1
        if 'anm' in method:
            print('不启用并行anm')
            rest_features = filter.anm_parallel(k=k)
        # elif method == 'anm':
        #     print('启用anm')
        #     rest_features = filter.anm(k=k)
        elif method == 'icalingam':
            raise ValueError('icalingam还在调试，并未启用')
            # rest_features = filter.lingam(mode='ica')
        elif method == 'directlingam':
            raise ValueError('directlingam还在调试，并未启用')
            # rest_features = filter.lingam(mode='direct')
        elif method == 'hsic':
            print('启用hsiclasso')
            rest_features = filter.hsiclasso(max_feature=k)
        elif method == 'varlingam':
            raise ValueError('varlingam还在调试，并未启用')
            # rest_features = filter.lingam(mode='var')
        else:
            print('默认启用并行anm方法')
            rest_features = filter.anm_parallel(k=k)
        # 对trainx和testx进行提取
        train_x2 = [df[rest_features] for df in self.strainx]
        test_x2 = [df[rest_features] for df in self.test_x]
        return train_x2, test_x2

    def Frame_causal_filter(self, ynum,method='anm', k=10):
        """
        实例化CausalFilter，并默认使用anm方法
        :return:
        """
        train_x, train_y, test_x = self.__getdata(ynum)
        ans, ansx = [], []

        for j in self.framelist:
            yname = []
            for x in self.strainx[0].columns:
                if j in x:
                    yname.append(x)
            k = 1
            filter = CausalFilter(train_x=[train_x[0][yname]],
                                  train_y=train_y,
                                  test_x=[test_x[0][yname]],
                                  nnn=self.nnn)
            if len(yname)>1:
                if 'anm' in method:
                    print('不启用并行anm')
                    rest_features = filter.anm_parallel(k=k)
                # elif method == 'anm':
                #     print('启用anm')
                #     rest_features = filter.anm(k=k)
                elif method == 'icalingam':
                    raise ValueError('icalingam还在调试，并未启用')
                    # rest_features = filter.lingam(mode='ica')
                elif method == 'directlingam':
                    raise ValueError('directlingam还在调试，并未启用')
                    # rest_features = filter.lingam(mode='direct')
                elif method == 'hsic':
                    print('启用hsiclasso')
                    try:
                        rest_features = filter.hsiclasso(max_feature=k)
                    except:
                        rest_features=[]
                elif method == 'varlingam':
                    raise ValueError('varlingam还在调试，并未启用')
                    # rest_features = filter.lingam(mode='var')
                else:
                    print('默认启用并行anm方法')
                    rest_features = filter.anm_parallel(k=k)
                ans=ans+rest_features
            else:
                ans=ans+yname

        # 对trainx和testx进行提取
        ansy = [df[ans] for df in self.strainx]
        ansyts = [df[ans] for df in self.test_x]
        return ansy , ansyts
    def correlation_filter(self, filter_name, ynums,k=None,Trainy=None,yname=None):
        """
        实例化CorrelationFilter
        """
        if k in None:
            k=self.k
        else:
            k=k
        if Trainy is None:
            train_y=self.train_y
        else:
            train_y=Trainy
        if yname is None:
            filter = CorrelationFilter(strainx=self.strainx,
                                       train_y=train_y,
                                       test_x=self.test_x,
                                       k=k,
                                       n_for=self.n_for,
                                       nnn=self.nnn,
                                       t=self.t)
            return filter.run(filter_name=filter_name, ynums=ynums)
        else:
            ans,ansx=[],[]
            yname=[]
            for j in self.framelist:
                for x in self.strainx[0].columns:
                    if j in x:
                        yname.append(x)
                filter = CorrelationFilter(strainx=[self.strainx[0][yname]],
                                           train_y=train_y,
                                           test_x=[self.test_x[0][yname]],
                                           k=1,
                                           n_for=self.n_for,
                                           nnn=self.nnn,
                                           t=self.t)
                tr,tx = filter.run(filter_name=filter_name, ynums=ynums)
                ans.append(tr)
                ansx.append(tx)
            return ans,ansx


    def run(self, filter_name, ynums=1):
        if filter_name[:5]=='Frame':
            #step1 finding best time-lag of features in frame
            filter_name2=filter_name[6:]
            if filter_name2[:6] != 'causal':
                framey, frameytx = self.correlation_filter(filter_name, ynums,yname=self.framelist)
                framey, frameytx=pd.concat(framey,axis=1),pd.concat(frameytx,axis=1)
                #step2 finding each index's features
                tr,tx=[],[]
                for y in range(framey[0].shape[1]):
                    tr_x2, te_x2 = self.correlation_filter(filter_name,ynums, k=np.int(np.ceil(self.k/framey[0].shape[1])),Train_y=[pd.DataFrame(framey[0].iloc[(x*int(framey[0].shape[0]/ynums)):((x+1)*int(framey[0].shape[0]/ynums)),y]) for x in range(ynums)])
                    tr_x2[0].columns=str(framey[0].columns[y])+'^^'+tr_x2[0].columns
                    te_x2[0].columns=str(framey[0].columns[y])+'^^'+te_x2[0].columns
                    tr=tr+tr_x2
                    tx=tx+te_x2
                train_x2, test_x2=[pd.concat(tr,axis=1).iloc[:,0:self.k]],[pd.concat(tx,axis=1).iloc[:,0:self.k]]
            elif filter_name2[:6] == 'causal':
                framey, frameytx = self.Frame_causal_filter(ynums,method=filter_name2[7:])
                #step2 finding each index's features
                tr,tx=[],[]
                for y in range(framey[0].shape[1]):
                    tr_x2, te_x2 = self.causal_filter(ynums, k1=np.int(np.ceil(self.k/framey[0].shape[1])),method=filter_name2[7:],Train_y=[pd.DataFrame(framey[0].iloc[(x*int(framey[0].shape[0]/ynums)):((x+1)*int(framey[0].shape[0]/ynums)),y]) for x in range(ynums)])
                    tr_x2[0].columns=str(framey[0].columns[y])+'^^'+tr_x2[0].columns
                    te_x2[0].columns=str(framey[0].columns[y])+'^^'+te_x2[0].columns
                    tr=tr+[tr_x2[0].iloc[:,:np.int(np.ceil(self.k/framey[0].shape[1]))]]
                    tx=tx+[te_x2[0].iloc[:,:np.int(np.ceil(self.k/framey[0].shape[1]))]]
                train_x2, test_x2=[pd.concat(tr,axis=1).iloc[:,0:self.k]],[pd.concat(tx,axis=1).iloc[:,0:self.k]]
        else:
            if filter_name[:6] != 'causal':
                # 相关性方法
                train_x2, test_x2 = self.correlation_filter(filter_name, ynums)
            elif filter_name[:6] == 'causal':
                # 因果发现方法
                train_x2, test_x2 = self.causal_filter(ynums, method=filter_name[7:])
            else:
                raise ValueError('输入特征工程未找到：{}'.format(filter_name))
        return train_x2, test_x2


class CorrelationFilter:
    """
    所有相关性过滤方法集合
    """

    def __init__(self, strainx, train_y, test_x, k, n_for, nnn=1, t=0):
        self.strainx = strainx
        self.train_y = train_y
        self.test_x = test_x
        self.k = k
        self.t = int(t)
        self.nnn = nnn
        self.n_for = n_for
        self.train_x2 = list(np.zeros((self.nnn, 1)))
        self.test_x2 = list(np.zeros((self.nnn, 1)))

    def cort(self):
        """
        CORT相关性方法
        :return:
        """

        # cort辅助计算
        def _cort_cal(d2):
            d22 = d2[:-1]
            d2_ = d2[1:]
            d2_d2 = d2_ - d22
            res = np.abs(np.dot(d2_d2.T, d1_d1) / (np.sqrt(np.dot(d2_d2.T, d2_d2)) * np.sqrt(np.dot(d1_d1.T, d1_d1))))
            return res

        # ----------- cort -------------
        for j in range(self.nnn):
            d1 = pd.DataFrame(self.train_y[j]).iloc[:-1, :]
            d1_ = pd.DataFrame(pd.DataFrame(self.train_y[j]).iloc[1:, :].values,
                               index=range(self.train_y[j].shape[0] - 1))
            d1_d1 = d1_ - d1
            index = []
            i = 0
            while np.array(index).shape[0] == 0 and self.k - i * 0.1 > 0:
                print(str(self.k - i * 0.1))
                cort = np.apply_along_axis(_cort_cal, 0, np.array(self.strainx[j]))
                cortm = pd.DataFrame(cort.reshape(1, len(cort.flatten())),
                                     columns=pd.DataFrame(self.strainx[j]).columns)
                cortaddname = cortm[cortm > (self.k - i * 0.1)].dropna(axis=1).columns
                index = index + list(cortaddname)
                i = i + 1
        return index

    def _findcorr(self, Ytrain_roll, Xtrain_roll, k1_1, X_num):
        while 1:
            chooseXmatrix2 = column_matrix_corr_matrix(Ytrain_roll, Xtrain_roll, k1_1)
            k1_1 -= 0.05
            if chooseXmatrix2.shape[1] > X_num:
                break
        return chooseXmatrix2.columns, k1_1

    def pearson(self):
        """
        pearson相关系数计算trainx和testx之间的相关性。
        :return:
        """
        for j in range(self.nnn):
            k2 = 0.8
            X_num = 30

            chooseX1, k1_1 = self._findcorr(self.train_y[j], self.strainx[j], self.k, X_num)
            tmptestx = pd.DataFrame(self.test_x[j], columns=self.strainx[j].columns)
            chooseX2, k1_2 = self._findcorr(self.train_y[j][-self.n_for:], tmptestx, self.k, X_num)
            XnameAll0 = chooseX1 & chooseX2

            while len(chooseX1) < 100:
                X_num += 100
                chooseX1, k1_1 = self._findcorr(self.train_y[j], self.strainx[j], k1_1, X_num)
                chooseX2, k1_2 = self._findcorr(self.train_y[j].iloc[-self.n_for:, ], self.test_x[j], k1_2, X_num)
                XnameAll0 = chooseX1 & chooseX2

            if len(XnameAll0) > 1:
                chooseXmatrix3 = del_dupli(self.strainx[j][XnameAll0], k2)

        return chooseXmatrix3.columns

    def hmimage(self, filter_name):
        if 'step' in filter_name:
            print('image_step')
            pic_len = int(64 / 72 * self.strainx[0].shape[0])
            if pic_len % 2 != 0:
                pic_len += 1
            image_method = int(filter_name[8])
            Hash_method = filter_name[10]
            feature_step = 1
            try:
                feature_step = int(filter_name[-1])
            except:
                pass
            print('feature_step={}'.format(feature_step))
            feature_index = list(set(
                np.linspace(0, np.floor(self.nnn / feature_step) * feature_step, int(np.floor(self.nnn / feature_step)),
                            endpoint=False, dtype=int)))
            if len(feature_index) == 0:
                feature_index = [0]
            print('要计算的期数为{}'.format(feature_index))
            feature_index.sort()
            strainx_cal = []
            train_y_cal = []
            test_x_cal = []
            for ff in feature_index:
                strainx_cal.append(self.strainx[ff])
                train_y_cal.append(self.train_y[ff])
                test_x_cal.append(self.test_x[ff])
            nnn_cal = len(feature_index)
            train_x2_cal = list(map(lambda x: cal_HMD(strainx_cal[x], train_y_cal[x], test_x_cal[x], list([pic_len]),
                                                      list([image_method]), list([int(self.k)]), list([Hash_method]))[
                0],
                                    range(nnn_cal)))
            test_x2_cal = list(map(lambda x: cal_HMD(strainx_cal[x], train_y_cal[x], test_x_cal[x], list([pic_len]),
                                                     list([image_method]), list([int(self.k)]), list([Hash_method]))[1],
                                   range(nnn_cal)))
            train_x2 = []
            test_x2 = []
            for j in range(self.nnn):
                if j in feature_index:
                    train_x2.append(train_x2_cal[feature_index.index(j)])
                    test_x2.append(test_x2_cal[feature_index.index(j)])
                    print("第{}个滚动期，计算特征工程".format(j + 1))
                else:
                    train_x2.append(self.strainx[j][train_x2[-1].columns])
                    tmptestx2 = pd.DataFrame(self.test_x[j], columns=self.strainx[j].columns)
                    test_x2.append(tmptestx2[test_x2[-1].columns])
                    print("第{}个滚动期，不计算特征工程".format(j + 1))
        else:
            print('image')
            pic_len = int(64 / 72 * self.strainx[0].shape[0])
            if pic_len % 2 != 0:
                pic_len += 1
            image_method = int(filter_name[8])
            Hash_method = filter_name[-1]
            from multiprocessing import Pool
            from feature_engineering.model_tools.Multi import cal_HMD
            # zip_args = list(zip(strainx, train_y, test_x, [list([pic_len]) for x in range(nnn)],
            #                     [list([image_method]) for x in range(nnn)], [list([k]) for x in range(nnn)],
            #                     [list([Hash_method]) for x in range(nnn)]))
            # pool = Pool(processes=6)
            # res = pool.starmap(cal_HMD, zip_args)
            # pool.close()
            # pool.join()
            train_x2 = list(map(lambda x:
                                cal_HMD(self.strainx[x], self.train_y[x], self.test_x[x], list([pic_len]),
                                        list([image_method]),
                                        list([self.k]), list([Hash_method]))[0], range(self.nnn)))
            print(train_x2)
            test_x2 = list(map(lambda x:
                               cal_HMD(self.strainx[x], self.train_y[x], self.test_x[x], list([pic_len]),
                                       list([image_method]),
                                       list([self.k]), list([Hash_method]))[1], range(self.nnn)))
        return train_x2, test_x2

    def dtw_filter(self):
        from model_tools.Multi import DTW_filter
        start_t = time.time()
        res = list(map(lambda x: DTW_filter(self.strainx[x], self.train_y[x], self.test_x[x], self.k, self.t),
                       range(self.nnn)))
        end_t = time.time()
        print('dtw运行耗时：{}'.format(end_t - start_t))

        train_x2 = list(map(lambda x: res[x][0], range(self.nnn)))
        print(train_x2)
        test_x2 = list(map(lambda x: res[x][1], range(self.nnn)))
        return train_x2, test_x2

    def run(self, filter_name, ynums=1):
        if filter_name == 'CORT':
            index = self.cort()
            for j in range(self.nnn):
                if np.array(index).shape[0] == 0:
                    print("阈值提取特征失败")
                    self.train_x2[j] = self.strainx[j]
                    self.test_x2[j] = self.test_x[j]
                else:
                    self.train_x2[j] = pd.DataFrame(pd.DataFrame(self.strainx[j])[index])
                    if self.test_x[j].shape[0] != 0:
                        self.test_x2[j] = pd.DataFrame(
                            pd.DataFrame(self.test_x[j], columns=self.strainx[j].columns)[index])
            return self.train_x2, self.test_x2

        elif filter_name == 'Pearson':
            index = self.pearson()
            for j in range(self.nnn):
                if np.array(index).shape[0] == 0:
                    print("阈值提取特征失败")
                    self.train_x2[j] = self.strainx[j]
                    self.test_x2[j] = self.test_x[j]
                else:
                    self.train_x2[j] = pd.DataFrame(pd.DataFrame(self.strainx[j])[index])
                    if self.test_x[j].shape[0] != 0:
                        self.test_x2[j] = pd.DataFrame(
                            pd.DataFrame(self.test_x[j], columns=self.strainx[j].columns)[index])

        elif filter_name[0:7] == "HMImage":
            raise ValueError('目前hmimage太慢暂不能使用')
            # return self.hmimage(filter_name)

        elif filter_name == 'DTWfilter':
            return self.dtw_filter()

        else:
            return self.dtw_filter()


class CausalFilter:
    """
    目前可用的因果推断模型方法用于筛选特征
    """

    def __init__(self, train_x, train_y, test_x, nnn=1, t=0, single_cpu=1):
        self.train_x = train_x
        self.train_y = train_y
        self.test_x = test_x
        self.nnn = nnn
        self.t = int(t)

    # ---------------------- pairwise based approach ------------------------
    def __data_auto_splite(self, k):
        """
        这个方法目前适用于pairwise的因果方法（anm, gnn），对于高维数据集遍历过慢的问题的优化，进行行列切分
        TODO: 对分块进行并行分组
        :return:
        """
        cut_x_list = []
        for j in range(self.nnn):
            part = math.ceil(self.train_x[j].shape[1] / int(k))
            i = 0
            if part <= self.train_x[j].shape[0] * 1 / 4:
                i = 1
            else:
                while part > self.train_x[j].shape[0] * 1 / 4:
                    i = i + 1
                    part = math.ceil(self.train_x[j].shape[1] / (i * int(k)))

            for cut in range(i * k):
                try:
                    cut_x_list.append(self.train_x[j].iloc[:, part * cut:part * (cut + 1)])
                except:
                    cut_x_list.append(self.train_x[j].iloc[:, part * cut:])
        return cut_x_list, part

    def __pairwise_assist(self, cutx, train_y, graph, model):
        """
        :param cutx:
        :param train_y:
        :param graph:
        :param model:
        :return:
        """
        y_name = train_y.columns.tolist()[-1]
        skeleton = graph.predict(pd.concat([train_y, cutx], axis=1))
        output_graph = model.predict(pd.concat([train_y, cutx], axis=1), skeleton)
        ans1 = pd.DataFrame(list(output_graph.edges(data='weight')), columns=['Cause', 'Effect', 'Score'])
        ans2 = ans1.sort_values(by='Score', ascending=False)
        score = ans2[ans2['Effect'] == y_name].iloc[0, :]
        nameindex = ans2[ans2['Effect'] == y_name]['Cause'].iloc[0]
        return score, nameindex

    def anm(self, k=10):
        """
        用到了对形式模型additive noise model，以及用glasso求data中的逆邻接矩阵。分组求跟y相关的最高anm得分的特征。
        :param k: 切割块的每个块的特征个数，默认10
        :return:
        """
        from cdt.independence.graph import Glasso
        from cdt.causality.pairwise import ANM
        glasso = Glasso()
        anm_model = ANM()

        # 数据集分割处理
        cut_x_list, part = self.__data_auto_splite(k=k)
        # 对每个cut_x_list里面的x分区执行
        for j in range(self.nnn):
            score = pd.DataFrame()
            for cutx in cut_x_list:
                try:
                    score1, _ = self.__pairwise_assist(cutx, self.train_y[j], glasso, anm_model)
                    score = pd.concat([score, score1], axis=1)
                except:
                    pass
            score.columns = score.loc['Cause']
        return list(score.loc['Score'].sort_values(ascending=False).index[int(self.t):int(self.t) + int(k)])

    def anm_serial(self, k=10):
        from causallearn.search.FCMBased.ANM.ANM import ANM
        anm_model = ANM()

        def _anm_assist(cutx, train_y, anm):
            df = pd.concat([cutx, train_y], axis=1)
            index_list = df.columns[:-1]
            anm_result = pd.DataFrame(columns=['Score'], index=index_list)
            n_row, n_len = df.shape[0], df.shape[1]
            for i in range(n_len - 1):
                p_forward, p_backward = anm.cause_or_effect(data_x=df.iloc[:, i].values.reshape(n_row, 1),
                                                            data_y=df.iloc[:, -1].values.reshape(n_row, 1))
                anm_result.loc[index_list[i]] = [p_forward - p_backward]
            return anm_result

        # 数据集分割处理
        cut_x_list, part = self.__data_auto_splite(k=k)

        # 对每个cut_x_list分区执行
        score = pd.DataFrame()
        ray_tmp = [_anm_assist(cutx, self.train_y[0], anm_model) for cutx in cut_x_list]
        for item in ray_tmp:
            score = pd.concat([score, item], axis=0)

        return list(score.sort_values(by=['Score'], ascending=False).index[int(self.t):int(self.t) + int(k)])

    def anm_parallel(self, num_cpus=8, k=10):
        """
        由于pairwise本身的特征，可以将这个过程做并行计算。使用基于python的Ray包。
        :param num_cpus: 调用的cpu个数
        :return:
        """
        from causallearn.search.FCMBased.ANM.ANM import ANM
        anm_model = ANM()

        # # 启动ray
        # if 'Windows' in platform():
        #     ray.init('ray://192.168.1.208:31666')
        # else:
        #     ray.init('ray://example-cluster-ray-head:10001')
        #
        # @ray.remote(num_cpus=1)
        def _anm_assist_ray(cutx, train_y, anm):
            df = pd.concat([cutx, train_y], axis=1)
            index_list = df.columns[:-1]
            anm_result = pd.DataFrame(columns=['Score'], index=index_list)
            n_row, n_len = df.shape[0], df.shape[1]
            for i in range(n_len - 1):
                p_forward, p_backward = anm.cause_or_effect(data_x=df.iloc[:, i].values.reshape(n_row, 1),
                                                            data_y=df.iloc[:, -1].values.reshape(n_row, 1))
                anm_result.loc[index_list[i]] = [p_forward - p_backward]
            return anm_result

        # 数据集分割处理
        cut_x_list, part = self.__data_auto_splite(k=k)

        # 对每个cut_x_list分区执行
        score = pd.DataFrame()
        # ray_tmp = ray.get([_anm_assist_ray.remote(cutx, self.train_y[0], anm_model) for cutx in cut_x_list])
        # # 停止ray
        # ray.shutdown()
        # for item in ray_tmp:
        #     score = pd.concat([score, item], axis=0)
        for cutx in cut_x_list:
            try:
                item=_anm_assist_ray(cutx, self.train_y[0], anm_model)
                score = pd.concat([score, item], axis=0)
            except:
                pass
        return list(score.sort_values(by=['Score'], ascending=False).index[int(self.t):int(self.t) + int(k)])

    def bivariate_fit(self, k=10):
        """
        双变量fit方法。原理为
        :param k:
        :return:
        """
        pass

    def sgnn(self, k=10):
        """
        shallow generative netural networks，一个cgnn的变形方法。
        TODO:速度太慢，仍需要优化
        :param k:选择特征个数，默认10
        :return:
        """
        from cdt.causality.pairwise import GNN
        from cdt.independence.graph import Glasso

        glasso = Glasso()
        gnn_model = GNN()
        # 数据集分割处理
        cut_x_list, part = self.__data_auto_splite(k=k)
        # 对每个cut_x_list里面的x分区执行
        for j in range(self.nnn):
            score = pd.DataFrame()
            nameindex = []
            for cutx in cut_x_list:
                try:
                    score1, nameindex1 = self.__pairwise_assist(cutx, self.train_y[j], glasso, gnn_model)
                    score = pd.concat([score, score1], axis=1)
                    nameindex.append(nameindex1)
                except:
                    pass
            score.columns = score.loc['Cause']
        return list(score.loc['Score'].sort_values(ascending=False).index[int(self.t):int(self.t) + int(k)])

    # ---------------------- graph based approach -------------------------
    def __lingam_causal_generator(self, model, df):
        """
        辅助进行两步操作：1.计算整个df的特征的相互因果排序；2.查询y的邻接矩阵。
        然后进行特征交集。
        :param model: lingam输入模型
        :param df:
        :return:
        """
        y_index = df.shape[1] - 1
        feature_names = df.columns.tolist()
        causal_order = model.causal_order_
        adj_matrix = model.adjacency_matrix_
        # 找到所有排在y之前的原因x的index1
        temp_order = causal_order[:causal_order.index(y_index) + 1]
        # 从邻接矩阵中找到和y相连的x的index2
        causal_index = np.nonzero(adj_matrix[y_index, :])
        # index1和index2进行交集
        cross_index = list(set(causal_index[0]).intersection(set(temp_order)))
        if len(cross_index) == len(causal_index[0]):
            causal_feature = []
            for i in causal_index[0]:
                causal_feature.append(feature_names[i])
        else:
            raise ValueError('邻接矩阵和因果排序中出现错误')
        return causal_feature

    def lingam(self, mode='ica', k=None):
        """
        一个基于方程的线性非高斯无环模型，使用ica求解，并得到一个因果排序。本方法并不是pairwise方法，
        所以不进行行列切割的方法对数据分块。
        在每个回测期都会计算一次当前期x与y的一个因果情况，并返回记录在字典里。最终字典内对每个滚动期
        每个有因果关系的特征都会做一次计数。根据出现次数排序，并根据num_features来选择最终的特征数。
        TODO：varlingam会出现奇异矩阵报错。
        :param k: 需要的特征数
        :return:
        """
        from causallearn.search.FCMBased import lingam
        causal_count_dict = {}
        for j in range(self.nnn):
            xy_combined = pd.concat([self.train_x[j], self.train_y[j]], axis=1)
            if mode == 'ica':
                model = lingam.ICALiNGAM()
            elif mode == 'var':
                raise ValueError('varlingam目前不支持，请使用ica或者direct')
                # model = lingam.VARLiNGAM(prune=True, criterion='bic')
            elif mode == 'direct':
                model = lingam.DirectLiNGAM()
            else:
                model = lingam.ICALiNGAM()

            model.fit(xy_combined)
            causal_feature = self.__lingam_causal_generator(model=model, df=xy_combined)

            for item in causal_feature:
                if item not in causal_count_dict.keys():
                    causal_count_dict[item] = 1
                else:
                    causal_count_dict[item] += 1

        causal_sorted = sorted(causal_count_dict.items(), key=lambda x: x[1], reverse=True)
        if k is None or k == len(causal_sorted):
            return [key for (key, v) in causal_sorted]
        else:
            if k > len(causal_sorted):
                raise ValueError('输出k大于待选x的长度')
            else:
                return [key for i, (key, v) in enumerate(causal_sorted) if i < k]

    def pc(self, k=None):
        """
        peter-clark方法，基本思想是统计（条件）独立的变量之间没有因果链接，是基于约束的算法的典型代表。
        利用数据中的条件独立关系来发掘潜在的因果结构。
        # TODO: 计算过程中产生奇异矩阵，目前没解决这个问题。
        :param k:
        :return:
        """
        from causallearn.search.ConstraintBased.PC import pc
        from causallearn.utils.cit import chisq, fisherz, gsq, kci, mv_fisherz

        for j in range(self.nnn):
            xy_combined = pd.concat([self.train_x[j], self.train_y[j]], axis=1)
            np.linalg.det(xy_combined.values)
            cg = pc(data=xy_combined.values,
                    alpha=0.05,
                    indep_test=fisherz,
                    stable=0,
                    uc_rule=-1)
        pass
    def hsiclasso(self, max_feature=None):
        """
        graphical lasso
        :param k:
        :return:
        """
        from cdt.independence.graph import HSICLasso
        obj = HSICLasso()
        if self.train_x[0].shape[1]>100:
            colindex = min(100,np.int(self.train_x[0].shape[1]/max_feature))
            best=[]
            for x in range(np.int(self.train_x[0].shape[1] / colindex)):
                if x>0:
                    data =self.train_x[0].iloc[:,x*colindex:(x+1)*colindex]
                    score = obj.predict_features(data, self.train_y[0])
                else:
                    data = self.train_x[0].iloc[:,0:colindex]
                    try:
                        score = obj.predict_features(self.train_x[0].iloc[:,0:colindex],self.train_y[0])
                    except:pass
                try:
                    tmp = pd.DataFrame(data=np.array(score), index=data.columns, columns=['Score'])
                    best.append(list(tmp.sort_values(by=['Score'], ascending=False).index[:1])[0])
                except:pass

            data = self.train_x[0][best]
        else:
            data=self.train_x[0]
        score = obj.predict_features(data, self.train_y[0])
        tmp = pd.DataFrame(data=np.array(score), index=data.columns, columns=['Score'])
        return list(abs(tmp).sort_values(by=['Score'], ascending=False).index[:max_feature])

    def pc_gpu(self):
        """
        pc方法的gpu版本，需要调用cdt包。
        TODO:cdt调用pc方法时需要同时调用r包，目前有几个R包在install中装不上。
        """
        pass

    def linear_granger(self):
        """
        格兰杰因果
        TODO:待开发。
        :return:
        """
        pass

# if __name__=='__main__':
    # import pickle
    # with open(r'D:\model0715\新建文件夹\train_x.pkl','rb') as pk_file:
    #     train_x=pickle.load(pk_file)
    # with open(r'D:\model0715\新建文件夹\train_y.pkl', 'rb') as pk_file:
    #     train_y = pickle.load(pk_file)
    # with open(r'D:\model0715\新建文件夹\test_x.pkl', 'rb') as pk_file:
    #     test_x = pickle.load(pk_file)
    # with open(r'D:\model0715\新建文件夹\dict_args.pkl', 'rb') as pk_file:
    #     dict_args = pickle.load(pk_file)
    # dict_args['framelist']=['上证综合指数','美国:国债收益率:10年']
    # dict_args['filter_name']='Frame-causal-hsic'
    # filter_obj = Filter(train_x,
    #                     train_y,
    #                     test_x, dict_args['kfilter'], dict_args['kfilter'],
    #                     framelist=dict_args['framelist'])
    # train_x4, test_x4 = filter_obj.run(dict_args['filter_name'], len(dict_args['Y_name']))
